#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int main() {
    int n, i;
    double min, max, sum = 0;
    double m[1000];
    printf("Input n, min, max: ");
    scanf_s("%d %lf %lf", &n, &min, &max);
    if (n <= 0 || n > 1000 || min >= max) {
        printf("Incorrect data");
        return 1;
    }
    srand((unsigned int)time(NULL));
    for (i = 0; i < n; i++) {
        m[i] = min + (max - min) * ((double)rand() / RAND_MAX);
        m[i] = round(m[i] * 100) / 100;
        printf("%d: %.2f\n", i + 1, m[i]);
        sum += m[i];
    }
    printf("Average = %.2f\n", sum / n);
    return 0;
}